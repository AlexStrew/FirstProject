const GameLogic = require('./gameLogic');

// Тестовая конфигурация
const config = {
    GROWTH_MIN: -5,
    GROWTH_MAX: 20,
    GROW_SHRINK_RATIO: 0.5,
    GROWTH_DOD_BONUS_MAX: 5,
    NEWCOMERS_GRACE_DAYS: 7,
    TOP_LIMIT: 10,
    PVP_DEFAULT_BET: 1,
    HELP_PUSSIES_COEF: 0.01,
    LOAN_PAYOUT_COEF: 0.1,
    DOD_SELECTION_MODE: 'EXCLUSION',
    DOD_RICH_EXCLUSION_RATIO: 0.1,
    ANNOUNCEMENT_MAX_SHOWS: 5
};

const gameLogic = new GameLogic(config);

console.log('🧪 Тестирование игровой логики...\n');

// Тест генерации роста
console.log('📈 Тест генерации роста:');
for (let i = 0; i < 10; i++) {
    const growth = gameLogic.generateGrowth();
    console.log(`   Рост ${i + 1}: ${gameLogic.formatGrowth(growth)} ${gameLogic.getGrowthEmoji(growth)}`);
}

// Тест расчета размера
console.log('\n📏 Тест расчета размера:');
const testSizes = [10, 5, 0, -5, -10];
testSizes.forEach(size => {
    const growth = 3;
    const newSize = gameLogic.calculateNewSize(size, growth);
    console.log(`   ${gameLogic.formatSize(size)} + ${gameLogic.formatGrowth(growth)} = ${gameLogic.formatSize(newSize)} ${gameLogic.getSizeEmoji(newSize)}`);
});

// Тест расчета кредита
console.log('\n💰 Тест расчета кредита:');
const testGrowths = [1, 5, 10, 20];
testGrowths.forEach(growth => {
    const payment = gameLogic.calculateLoanPayment(growth);
    console.log(`   Рост ${growth} см → выплата по кредиту: ${payment.toFixed(1)} см`);
});

// Тест выбора Писюна Дня
console.log('\n👑 Тест выбора Писюна Дня:');
const mockUsers = [
    { telegram_id: 1, username: 'user1', first_name: 'User', last_name: 'One', dick_size: 5 },
    { telegram_id: 2, username: 'user2', first_name: 'User', last_name: 'Two', dick_size: 10 },
    { telegram_id: 3, username: 'user3', first_name: 'User', last_name: 'Three', dick_size: 15 },
    { telegram_id: 4, username: 'user4', first_name: 'User', last_name: 'Four', dick_size: 20 },
    { telegram_id: 5, username: 'user5', first_name: 'User', last_name: 'Five', dick_size: 25 }
];

const dodWinner = gameLogic.selectDOD(mockUsers);
if (dodWinner) {
    console.log(`   Победитель: ${dodWinner.first_name} ${dodWinner.last_name} (${gameLogic.formatSize(dodWinner.dick_size)})`);
    const bonus = gameLogic.generateDODBonus();
    console.log(`   Бонус: +${bonus.toFixed(1)} см`);
}

// Тест PvP
console.log('\n⚔️ Тест PvP:');
const challenger = mockUsers[0];
const opponent = mockUsers[1];
const winner = gameLogic.determinePvPWinner(challenger, opponent);
console.log(`   ${challenger.first_name} vs ${opponent.first_name}`);
console.log(`   Победитель: ${winner.first_name} ${winner.last_name}`);

// Тест парсинга PvP команд
console.log('\n🔧 Тест парсинга PvP команд:');
const pvpCommands = [
    '/pvp @Doker_rs',
    '/pvp @Doker_rs 5',
    '/pvp @user123 10',
    '/pvp @test 3.5'
];

pvpCommands.forEach(cmd => {
    const match = cmd.match(/\/pvp (.+)/);
    if (match) {
        const args = match[1].split(' ');
        const username = args[0].replace('@', '');
        const bet = args.length > 1 ? parseInt(args[1]) : config.PVP_DEFAULT_BET;
        console.log(`   ${cmd} → username: @${username}, ставка: ${bet} см`);
    }
});

// Тест ограничений ставок PvP
console.log('\n⚠️ Тест ограничений ставок PvP:');
const testPvPScenarios = [
    { challenger: { dick_size: 5 }, opponent: { dick_size: 10 }, bet: 3, description: 'Оба могут ставить' },
    { challenger: { dick_size: 5 }, opponent: { dick_size: 10 }, bet: 7, description: 'Челленджер не может ставить' },
    { challenger: { dick_size: 15 }, opponent: { dick_size: 3 }, bet: 5, description: 'Оппонент не может ставить' },
    { challenger: { dick_size: 2 }, opponent: { dick_size: 8 }, bet: 10, description: 'Никто не может ставить' }
];

testPvPScenarios.forEach((scenario, index) => {
    const challengerCanBet = scenario.challenger.dick_size >= scenario.bet;
    const opponentCanBet = scenario.opponent.dick_size >= scenario.bet;
    
    console.log(`   Сценарий ${index + 1}: ${scenario.description}`);
    console.log(`   Челленджер (${scenario.challenger.dick_size} см) может ставить ${scenario.bet} см: ${challengerCanBet ? '✅' : '❌'}`);
    console.log(`   Оппонент (${scenario.opponent.dick_size} см) может ставить ${scenario.bet} см: ${opponentCanBet ? '✅' : '❌'}`);
    console.log(`   Результат: ${challengerCanBet && opponentCanBet ? '✅ Можно сражаться' : '❌ Нельзя сражаться'}\n`);
});

// Тест рейтинга по чатам
console.log('\n🏆 Тест рейтинга по чатам:');
const mockGlobalUsers = [
    { telegram_id: 1, username: 'global1', first_name: 'Global', last_name: 'One', dick_size: 30 },
    { telegram_id: 2, username: 'global2', first_name: 'Global', last_name: 'Two', dick_size: 25 },
    { telegram_id: 3, username: 'global3', first_name: 'Global', last_name: 'Three', dick_size: 20 }
];

const mockChatUsers = [
    { telegram_id: 4, username: 'chat1', first_name: 'Chat', last_name: 'One', dick_size: 15 },
    { telegram_id: 5, username: 'chat2', first_name: 'Chat', last_name: 'Two', dick_size: 10 },
    { telegram_id: 6, username: 'chat3', first_name: 'Chat', last_name: 'Three', dick_size: 5 }
];

console.log('   🌍 Общий рейтинг (ТОП 3):');
mockGlobalUsers.forEach((user, index) => {
    const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : '🥉';
    const size = gameLogic.formatSize(user.dick_size);
    const emoji = gameLogic.getSizeEmoji(user.dick_size);
    console.log(`   ${medal} ${user.first_name} ${user.last_name}: ${size} ${emoji}`);
});

console.log('\n   💬 Рейтинг в чате (ТОП 3):');
mockChatUsers.forEach((user, index) => {
    const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : '🥉';
    const size = gameLogic.formatSize(user.dick_size);
    const emoji = gameLogic.getSizeEmoji(user.dick_size);
    console.log(`   ${medal} ${user.first_name} ${user.last_name}: ${size} ${emoji}`);
});

// Тест админской команды
console.log('\n👑 Тест админской команды:');
const adminCommands = [
    '/edit @wattbe 24',
    '/edit @user123 15.5',
    '/edit @test -5'
];

adminCommands.forEach(cmd => {
    const match = cmd.match(/\/edit (.+)/);
    if (match) {
        const args = match[1].split(' ');
        const username = args[0].replace('@', '');
        const newSize = parseFloat(args[1]);
        console.log(`   ${cmd} → username: @${username}, новый размер: ${newSize} см`);
    }
});

// Тест информации о Писюне Дня
console.log('\n👑 Тест информации о Писюне Дня:');
const mockChat = {
    dod_winner_id: 1,
    last_dod_date: new Date().toISOString()
};

const mockWinner = mockUsers.find(u => u.telegram_id === mockChat.dod_winner_id);
if (mockWinner) {
    console.log(`   Текущий Писюн Дня: ${mockWinner.first_name} ${mockWinner.last_name}`);
    console.log(`   Размер: ${gameLogic.formatSize(mockWinner.dick_size)} ${gameLogic.getSizeEmoji(mockWinner.dick_size)}`);
    console.log(`   Дата выбора: ${new Date(mockChat.last_dod_date).toLocaleString()}`);
}

console.log('\n✅ Все тесты завершены!'); 