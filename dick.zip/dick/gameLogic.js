const moment = require('moment');

class GameLogic {
    constructor(config) {
        this.config = config;
    }

    // Генерация случайного роста
    generateGrowth() {
        const min = this.config.GROWTH_MIN || -5;
        const max = this.config.GROWTH_MAX || 20;
        return Math.round((Math.random() * (max - min) + min) * 10) / 10;
    }

    // Проверка, можно ли расти сегодня
    canGrowToday(lastGrowDate) {
        if (!lastGrowDate) return true;
        
        const lastGrow = moment(lastGrowDate);
        const today = moment().startOf('day');
        
        return lastGrow.isBefore(today);
    }

    // Расчет нового размера с учетом кредита
    calculateNewSize(currentSize, growthAmount) {
        let newSize = currentSize + growthAmount;
        
        // Если размер отрицательный, применяем бонус для "помощи писюнам"
        if (newSize < 0) {
            const debt = Math.abs(newSize);
            const bonus = debt * (this.config.HELP_PUSSIES_COEF || 0.01);
            newSize += bonus;
        }
        
        return Math.round(newSize * 10) / 10;
    }

    // Расчет выплаты по кредиту
    calculateLoanPayment(growthAmount) {
        if (growthAmount <= 0) return 0;
        
        const payment = growthAmount * (this.config.LOAN_PAYOUT_COEF || 0.1);
        return Math.round(payment * 10) / 10;
    }

    // Проверка, можно ли выбрать Писюна Дня
    canSelectDOD(lastDODDate) {
        if (!lastDODDate) return true;
        
        const lastDOD = moment(lastDODDate);
        const today = moment().startOf('day');
        
        return lastDOD.isBefore(today);
    }

    // Выбор Писюна Дня
    selectDOD(activeGrowers) {
        if (!activeGrowers || activeGrowers.length === 0) {
            return null;
        }

        const mode = this.config.DOD_SELECTION_MODE || 'EXCLUSION';
        
        switch (mode) {
            case 'RANDOM':
                return this.selectRandomDOD(activeGrowers);
            case 'EXCLUSION':
                return this.selectExclusionDOD(activeGrowers);
            case 'WEIGHTS':
                return this.selectWeightedDOD(activeGrowers);
            default:
                return this.selectExclusionDOD(activeGrowers);
        }
    }

    selectRandomDOD(activeGrowers) {
        const randomIndex = Math.floor(Math.random() * activeGrowers.length);
        return activeGrowers[randomIndex];
    }

    selectExclusionDOD(activeGrowers) {
        const exclusionRatio = this.config.DOD_RICH_EXCLUSION_RATIO || 0.1;
        const excludeCount = Math.floor(activeGrowers.length * exclusionRatio);
        
        // Исключаем топ игроков
        const eligibleGrowers = activeGrowers.slice(excludeCount);
        
        if (eligibleGrowers.length === 0) {
            return activeGrowers[0]; // Если все исключены, берем первого
        }
        
        return this.selectRandomDOD(eligibleGrowers);
    }

    selectWeightedDOD(activeGrowers) {
        // Чем меньше размер, тем больше шансов
        const weights = activeGrowers.map(user => {
            const maxSize = Math.max(...activeGrowers.map(u => u.dick_size));
            return maxSize - user.dick_size + 1; // +1 чтобы избежать нулевых весов
        });
        
        const totalWeight = weights.reduce((sum, weight) => sum + weight, 0);
        let random = Math.random() * totalWeight;
        
        for (let i = 0; i < activeGrowers.length; i++) {
            random -= weights[i];
            if (random <= 0) {
                return activeGrowers[i];
            }
        }
        
        return activeGrowers[0];
    }

    // Генерация бонуса для Писюна Дня
    generateDODBonus() {
        const max = this.config.GROWTH_DOD_BONUS_MAX || 5;
        return Math.round((Math.random() * max + 1) * 10) / 10;
    }

    // PvP логика
    determinePvPWinner(challenger, opponent) {
        // Простая случайная логика, можно усложнить
        return Math.random() > 0.5 ? challenger : opponent;
    }

    // Форматирование размера для отображения
    formatSize(size) {
        if (size >= 0) {
            return `${size.toFixed(1)} см`;
        } else {
            return `${size.toFixed(1)} см (в долгах)`;
        }
    }

    // Форматирование роста для отображения
    formatGrowth(growth) {
        if (growth > 0) {
            return `+${growth.toFixed(1)} см`;
        } else {
            return `${growth.toFixed(1)} см`;
        }
    }

    // Проверка, является ли пользователь новичком
    isNewcomer(createdAt, graceDays = 7) {
        if (!createdAt) return true;
        
        const created = moment(createdAt);
        const gracePeriod = moment().subtract(graceDays, 'days');
        
        return created.isAfter(gracePeriod);
    }

    // Получение эмодзи для размера
    getSizeEmoji(size) {
        if (size < 0) return '😭';
        if (size < 5) return '😔';
        if (size < 10) return '😐';
        if (size < 15) return '😊';
        if (size < 20) return '😎';
        if (size < 30) return '🤩';
        return '👑';
    }

    // Получение эмодзи для роста
    getGrowthEmoji(growth) {
        if (growth > 15) return '🚀';
        if (growth > 10) return '🔥';
        if (growth > 5) return '💪';
        if (growth > 0) return '📈';
        if (growth > -5) return '📉';
        return '💀';
    }
}

module.exports = GameLogic; 