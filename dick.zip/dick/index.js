require('dotenv').config();
const DickGrowthBot = require('./bot');

// Конфигурация из переменных окружения
const config = {
    GROWTH_MIN: parseInt(process.env.GROWTH_MIN) || -5,
    GROWTH_MAX: parseInt(process.env.GROWTH_MAX) || 20,
    GROW_SHRINK_RATIO: parseFloat(process.env.GROW_SHRINK_RATIO) || 0.5,
    GROWTH_DOD_BONUS_MAX: parseInt(process.env.GROWTH_DOD_BONUS_MAX) || 5,
    NEWCOMERS_GRACE_DAYS: parseInt(process.env.NEWCOMERS_GRACE_DAYS) || 7,
    TOP_LIMIT: parseInt(process.env.TOP_LIMIT) || 10,
    PVP_DEFAULT_BET: parseInt(process.env.PVP_DEFAULT_BET) || 1,
    HELP_PUSSIES_COEF: parseFloat(process.env.HELP_PUSSIES_COEF) || 0.01,
    LOAN_PAYOUT_COEF: parseFloat(process.env.LOAN_PAYOUT_COEF) || 0.1,
    DOD_SELECTION_MODE: process.env.DOD_SELECTION_MODE || 'EXCLUSION',
    DOD_RICH_EXCLUSION_RATIO: parseFloat(process.env.DOD_RICH_EXCLUSION_RATIO) || 0.1,
    ANNOUNCEMENT_MAX_SHOWS: parseInt(process.env.ANNOUNCEMENT_MAX_SHOWS) || 5
};

// Проверяем наличие токена
const token = process.env.BOT_TOKEN;
if (!token) {
    console.error('❌ Ошибка: BOT_TOKEN не найден в переменных окружения!');
    console.log('📝 Создайте файл .env и добавьте в него:');
    console.log('BOT_TOKEN=your_telegram_bot_token_here');
    process.exit(1);
}

console.log('🚀 Запуск Telegram бота "Расти писюн"...');
console.log('📊 Конфигурация:');
console.log(`   Рост: ${config.GROWTH_MIN} до ${config.GROWTH_MAX} см`);
console.log(`   Топ игроков: ${config.TOP_LIMIT}`);
console.log(`   PvP ставка: ${config.PVP_DEFAULT_BET} см`);
console.log(`   Режим Писюна Дня: ${config.DOD_SELECTION_MODE}`);

// Создаем и запускаем бота
const bot = new DickGrowthBot(token, config);

// Обработка завершения работы
process.on('SIGINT', () => {
    console.log('\n🛑 Получен сигнал завершения работы...');
    bot.stop();
    console.log('✅ Бот остановлен');
    process.exit(0);
});

process.on('SIGTERM', () => {
    console.log('\n🛑 Получен сигнал завершения работы...');
    bot.stop();
    console.log('✅ Бот остановлен');
    process.exit(0);
});

console.log('✅ Бот успешно запущен!');
console.log('📱 Отправьте /start в Telegram для начала игры'); 