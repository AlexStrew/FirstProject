const TelegramBot = require('node-telegram-bot-api');
const Database = require('./database');
const GameLogic = require('./gameLogic');
const moment = require('moment');

class DickGrowthBot {
    constructor(token, config) {
        this.bot = new TelegramBot(token, { polling: true });
        this.db = new Database();
        this.gameLogic = new GameLogic(config);
        this.config = config;
        
        this.setupHandlers();
    }

    setupHandlers() {
        // Команда /start
        this.bot.onText(/\/start/, this.handleStart.bind(this));
        
        // Команда /grow
        this.bot.onText(/\/grow/, this.handleGrow.bind(this));
        
        // Команда /top
        this.bot.onText(/\/top/, this.handleTop.bind(this));
        
        // Команда /pvp
        this.bot.onText(/\/pvp (.+)/, this.handlePvP.bind(this));
        
        // Команда /edit для админа
        this.bot.onText(/\/edit (.+)/, this.handleEdit.bind(this));
        
        // Команда /loan
        this.bot.onText(/\/loan/, this.handleLoan.bind(this));
        
        // Команда /dod (Писюн Дня)
        this.bot.onText(/\/dod/, this.handleDOD.bind(this));
        
        // Команда /dodinfo (информация о Писюне Дня)
        this.bot.onText(/\/dodinfo/, this.handleDODInfo.bind(this));
        
        // Команда /help
        this.bot.onText(/\/help/, this.handleHelp.bind(this));
        
        // Команда /accept для PvP
        this.bot.onText(/\/accept (.+)/, this.handleAcceptPvP.bind(this));
        
        // Обработка ошибок
        this.bot.on('polling_error', (error) => {
            console.error('Polling error:', error);
        });
    }

    async handleStart(msg) {
        const chatId = msg.chat.id;
        const user = msg.from;
        
        try {
            // Проверяем, существует ли пользователь
            let dbUser = await this.db.getUser(user.id);
            
            if (!dbUser) {
                await this.db.createUser(user);
                dbUser = await this.db.getUser(user.id);
            }
            
            const welcomeMessage = `🎉 Добро пожаловать в игру "Расти писюн"!
            
Ты же хочешь иметь самую большую пипиську в мире? Я уверен, что да. Просто /grow (расти) его раз в день в каждом чате! Поднимись на вершину рейтинга!

📏 Твой текущий размер: ${this.gameLogic.formatSize(dbUser.dick_size)} ${this.gameLogic.getSizeEmoji(dbUser.dick_size)}

Доступные команды:
/grow - Растить писюн (раз в день)
/top - Показать рейтинг
/pvp @username - Сразиться с другом
/loan - Взять кредит (если в минусах)
/dod - Выбрать Писюна Дня
/help - Помощь

Удачи в росте! 🚀`;

            await this.bot.sendMessage(chatId, welcomeMessage);
        } catch (error) {
            console.error('Error in handleStart:', error);
            await this.bot.sendMessage(chatId, 'Произошла ошибка при запуске бота.');
        }
    }

    async handleGrow(msg) {
        const chatId = msg.chat.id;
        const user = msg.from;
        
        try {
            // Проверяем, существует ли пользователь
            let dbUser = await this.db.getUser(user.id);
            
            if (!dbUser) {
                await this.db.createUser(user);
                dbUser = await this.db.getUser(user.id);
            }
            
            // Проверяем, можно ли расти сегодня
            if (!this.gameLogic.canGrowToday(dbUser.last_grow_date)) {
                const nextGrow = moment(dbUser.last_grow_date).add(1, 'day').startOf('day');
                const timeLeft = moment(nextGrow).diff(moment(), 'hours');
                
                await this.bot.sendMessage(chatId, 
                    `⏰ Ты уже растил свой писюн сегодня! Следующий рост будет доступен через ${timeLeft} часов.`);
                return;
            }
            
            // Генерируем рост
            const growth = this.gameLogic.generateGrowth();
            const oldSize = dbUser.dick_size;
            const newSize = this.gameLogic.calculateNewSize(oldSize, growth);
            
            // Обновляем размер в базе
            await this.db.updateUserDickSize(user.id, newSize, growth, 'daily_grow', chatId);
            
            // Формируем сообщение
            let message = `🍆 ${this.getUserDisplayName(user)} растит свой писюн!\n\n`;
            message += `📏 Было: ${this.gameLogic.formatSize(oldSize)}\n`;
            message += `📈 Изменение: ${this.gameLogic.formatGrowth(growth)} ${this.gameLogic.getGrowthEmoji(growth)}\n`;
            message += `📏 Стало: ${this.gameLogic.formatSize(newSize)} ${this.gameLogic.getSizeEmoji(newSize)}`;
            
            // Если есть кредит, показываем информацию о выплате
            if (dbUser.loan_amount > 0 && growth > 0) {
                const payment = this.gameLogic.calculateLoanPayment(growth);
                const remainingLoan = Math.max(0, dbUser.loan_amount - payment);
                
                message += `\n💰 Кредит: ${dbUser.loan_amount.toFixed(1)} → ${remainingLoan.toFixed(1)} см`;
                
                // Обновляем кредит
                await this.db.updateLoan(user.id, remainingLoan);
            }
            
            await this.bot.sendMessage(chatId, message);
            
        } catch (error) {
            console.error('Error in handleGrow:', error);
            await this.bot.sendMessage(chatId, 'Произошла ошибка при росте писюна.');
        }
    }

    async handleTop(msg) {
        const chatId = msg.chat.id;
        
        try {
            // Получаем общий рейтинг
            const globalTopUsers = await this.db.getTopUsers(this.config.TOP_LIMIT || 10);
            
            // Получаем рейтинг по чату
            const chatTopUsers = await this.db.getTopUsersByChat(chatId, this.config.TOP_LIMIT || 10);
            
            let message = '';
            
            // Общий рейтинг
            if (globalTopUsers.length > 0) {
                message += `🌍 ОБЩИЙ РЕЙТИНГ (ТОП ${globalTopUsers.length}):\n\n`;
                
                globalTopUsers.forEach((user, index) => {
                    const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `${index + 1}.`;
                    const displayName = this.getUserDisplayName(user);
                    const size = this.gameLogic.formatSize(user.dick_size);
                    const emoji = this.gameLogic.getSizeEmoji(user.dick_size);
                    
                    message += `${medal} ${displayName}: ${size} ${emoji}\n`;
                });
            } else {
                message += '🌍 ОБЩИЙ РЕЙТИНГ:\n📊 Пока нет данных для рейтинга.\n\n';
            }
            
            // Рейтинг по чату
            message += `\n💬 РЕЙТИНГ В ЭТОМ ЧАТЕ (ТОП ${chatTopUsers.length}):\n\n`;
            
            if (chatTopUsers.length > 0) {
                chatTopUsers.forEach((user, index) => {
                    const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `${index + 1}.`;
                    const displayName = this.getUserDisplayName(user);
                    const size = this.gameLogic.formatSize(user.dick_size);
                    const emoji = this.gameLogic.getSizeEmoji(user.dick_size);
                    
                    message += `${medal} ${displayName}: ${size} ${emoji}\n`;
                });
            } else {
                message += '📊 Пока нет активных игроков в этом чате.';
            }
            
            await this.bot.sendMessage(chatId, message);
            
        } catch (error) {
            console.error('Error in handleTop:', error);
            await this.bot.sendMessage(chatId, 'Произошла ошибка при получении рейтинга.');
        }
    }

    async handlePvP(msg, match) {
        const chatId = msg.chat.id;
        const challenger = msg.from;
        const args = match[1].split(' ');
        const opponentUsername = args[0].replace('@', '');
        const betAmount = args.length > 1 ? parseInt(args[1]) : this.config.PVP_DEFAULT_BET || 1;
        
        try {
            // Проверяем, существует ли пользователь
            let challengerUser = await this.db.getUser(challenger.id);
            if (!challengerUser) {
                await this.db.createUser(challenger);
                challengerUser = await this.db.getUser(challenger.id);
            }
            
            // Ищем оппонента по username
            const opponentUser = await this.db.getUserByUsername(opponentUsername);
            if (!opponentUser) {
                await this.bot.sendMessage(chatId, `❌ Пользователь @${opponentUsername} не найден.`);
                return;
            }
            
            if (opponentUser.telegram_id === challenger.id) {
                await this.bot.sendMessage(chatId, '❌ Нельзя сражаться с самим собой!');
                return;
            }
            
            // Проверяем, достаточно ли у оппонента сантиметров для ставки
            if (opponentUser.dick_size < betAmount) {
                await this.bot.sendMessage(chatId, 
                    `❌ У оппонента недостаточно сантиметров для ставки! У ${this.getUserDisplayName(opponentUser)} ${this.gameLogic.formatSize(opponentUser.dick_size)}, а ставка ${betAmount} см.`);
                return;
            }
            
            // Проверяем валидность ставки
            if (isNaN(betAmount) || betAmount <= 0) {
                await this.bot.sendMessage(chatId, '❌ Неверная ставка! Используйте: /pvp @username [ставка]');
                return;
            }
            
            // Проверяем, достаточно ли у игрока сантиметров для ставки
            if (challengerUser.dick_size < betAmount) {
                await this.bot.sendMessage(chatId, 
                    `❌ Недостаточно сантиметров для ставки! У вас ${this.gameLogic.formatSize(challengerUser.dick_size)}, а ставка ${betAmount} см.`);
                return;
            }
            
            // Создаем PvP сражение
            await this.db.createPvPBattle(chatId, challenger.id, opponentUser.telegram_id, betAmount);
            
            const message = `⚔️ ${this.getUserDisplayName(challenger)} вызывает на бой ${this.getUserDisplayName(opponentUser)}!
            
Ставка: ${betAmount} см
Победитель получит ${betAmount} см, проигравший потеряет ${betAmount} см.

Для принятия вызова ответьте: /accept @${challenger.username}`;
            
            await this.bot.sendMessage(chatId, message);
            
        } catch (error) {
            console.error('Error in handlePvP:', error);
            await this.bot.sendMessage(chatId, 'Произошла ошибка при создании PvP сражения.');
        }
    }

    async handleLoan(msg) {
        const chatId = msg.chat.id;
        const user = msg.from;
        
        try {
            let dbUser = await this.db.getUser(user.id);
            if (!dbUser) {
                await this.db.createUser(user);
                dbUser = await this.db.getUser(user.id);
            }
            
            if (dbUser.dick_size >= 0) {
                await this.bot.sendMessage(chatId, '❌ Кредит доступен только для тех, кто в глубоких минусах!');
                return;
            }
            
            if (dbUser.loan_amount > 0) {
                await this.bot.sendMessage(chatId, `💰 У тебя уже есть кредит: ${dbUser.loan_amount.toFixed(1)} см`);
                return;
            }
            
            // Обнуляем размер и устанавливаем кредит
            const loanAmount = Math.abs(dbUser.dick_size);
            await this.db.updateUserDickSize(user.id, 0, loanAmount, 'loan', chatId);
            await this.db.updateLoan(user.id, loanAmount);
            
            const message = `💰 Кредит оформлен!
            
📏 Твой размер обнулен до 0 см
💳 Кредит: ${loanAmount.toFixed(1)} см
📝 Каждый положительный рост будет частично идти на погашение кредита.`;
            
            await this.bot.sendMessage(chatId, message);
            
        } catch (error) {
            console.error('Error in handleLoan:', error);
            await this.bot.sendMessage(chatId, 'Произошла ошибка при оформлении кредита.');
        }
    }

    async handleDOD(msg) {
        const chatId = msg.chat.id;
        
        try {
            // Проверяем, существует ли чат
            let chat = await this.db.getChat(chatId);
            if (!chat) {
                await this.db.createChat({ id: chatId, title: msg.chat.title || 'Unknown Chat' });
                chat = await this.db.getChat(chatId);
            }
            
            // Проверяем, можно ли выбрать Писюна Дня
            if (!this.gameLogic.canSelectDOD(chat.last_dod_date)) {
                const nextDOD = moment(chat.last_dod_date).add(1, 'day').startOf('day');
                const timeLeft = moment(nextDOD).diff(moment(), 'hours');
                
                let message = `⏰ Писюн Дня уже выбран сегодня! Следующий выбор будет доступен через ${timeLeft} часов.`;
                
                // Показываем информацию о текущем Писюне Дня
                if (chat.dod_winner_id) {
                    const winnerUser = await this.db.getUser(chat.dod_winner_id);
                    if (winnerUser) {
                        message += `\n\n👑 Текущий Писюн Дня: ${this.getUserDisplayName(winnerUser)} (${this.gameLogic.formatSize(winnerUser.dick_size)}) ${this.gameLogic.getSizeEmoji(winnerUser.dick_size)}`;
                    }
                }
                
                await this.bot.sendMessage(chatId, message);
                return;
            }
            
            // Получаем активных гроверов
            const activeGrowers = await this.db.getActiveGrowers(chatId, 7);
            
            if (activeGrowers.length === 0) {
                await this.bot.sendMessage(chatId, '😔 Нет активных гроверов для выбора Писюна Дня.');
                return;
            }
            
            // Выбираем Писюна Дня
            const dodWinner = this.gameLogic.selectDOD(activeGrowers);
            const bonus = this.gameLogic.generateDODBonus();
            
            // Обновляем размер победителя
            const winnerUser = await this.db.getUser(dodWinner.telegram_id);
            const newSize = this.gameLogic.calculateNewSize(winnerUser.dick_size, bonus);
            await this.db.updateUserDickSize(dodWinner.telegram_id, newSize, bonus, 'dod_bonus', chatId);
            
            // Обновляем информацию о чате
            await this.db.updateChatDOD(chatId, dodWinner.telegram_id);
            
            const message = `👑 ПИСЮН ДНЯ: ${this.getUserDisplayName(dodWinner)}!
            
🎁 Бонус: +${bonus.toFixed(1)} см
📏 Новый размер: ${this.gameLogic.formatSize(newSize)} ${this.gameLogic.getSizeEmoji(newSize)}

Поздравляем победителя! 🎉`;
            
            await this.bot.sendMessage(chatId, message);
            
        } catch (error) {
            console.error('Error in handleDOD:', error);
            await this.bot.sendMessage(chatId, 'Произошла ошибка при выборе Писюна Дня.');
        }
    }

    async handleDODInfo(msg) {
        const chatId = msg.chat.id;
        
        try {
            // Проверяем, существует ли чат
            let chat = await this.db.getChat(chatId);
            if (!chat) {
                await this.db.createChat({ id: chatId, title: msg.chat.title || 'Unknown Chat' });
                chat = await this.db.getChat(chatId);
            }
            
            if (!chat.dod_winner_id) {
                await this.bot.sendMessage(chatId, '👑 Писюн Дня еще не выбран в этом чате. Используйте /dod для выбора!');
                return;
            }
            
            // Получаем информацию о победителе
            const winnerUser = await this.db.getUser(chat.dod_winner_id);
            if (!winnerUser) {
                await this.bot.sendMessage(chatId, '❌ Информация о Писюне Дня недоступна.');
                return;
            }
            
            // Проверяем, можно ли выбрать нового Писюна Дня
            const canSelectNew = this.gameLogic.canSelectDOD(chat.last_dod_date);
            let message = `👑 ИНФОРМАЦИЯ О ПИСЮНЕ ДНЯ\n\n`;
            message += `🏆 Победитель: ${this.getUserDisplayName(winnerUser)}\n`;
            message += `📏 Размер: ${this.gameLogic.formatSize(winnerUser.dick_size)} ${this.gameLogic.getSizeEmoji(winnerUser.dick_size)}\n`;
            message += `📅 Дата выбора: ${moment(chat.last_dod_date).format('DD.MM.YYYY HH:mm')}\n\n`;
            
            if (canSelectNew) {
                message += `✅ Можно выбрать нового Писюна Дня! Используйте /dod`;
            } else {
                const nextDOD = moment(chat.last_dod_date).add(1, 'day').startOf('day');
                const timeLeft = moment(nextDOD).diff(moment(), 'hours');
                message += `⏰ Следующий выбор будет доступен через ${timeLeft} часов`;
            }
            
            await this.bot.sendMessage(chatId, message);
            
        } catch (error) {
            console.error('Error in handleDODInfo:', error);
            await this.bot.sendMessage(chatId, 'Произошла ошибка при получении информации о Писюне Дня.');
        }
    }

    async handleHelp(msg) {
        const chatId = msg.chat.id;
        
        const helpMessage = `📖 ПОМОЩЬ ПО ИГРЕ "РАСТИ писюн"

🎯 Цель: Иметь самую большую пипиську в мире!

📋 Команды:
/grow - Растить писюн (раз в день)
/top - Показать общий рейтинг и рейтинг чата
/pvp @username [ставка] - Сразиться с другом
/loan - Взять кредит (если в минусах)
/dod - Выбрать Писюна Дня
/dodinfo - Информация о текущем Писюне Дня
/help - Показать эту справку

📊 Механики:
• Рост: от -5 до +20 см в день
• Писюн Дня: ежедневный бонус активным игрокам
• PvP: сражения с друзьями за сантиметры (ставка по умолчанию: 1 см)
• Кредит: для тех, кто в глубоких минусах

💰 Бонусы для минусовых:
• Каждый прирост увеличен на 1% от размера долга
• Команда /loan обнуляет размер в кредит

⚔️ PvP команды:
• /pvp @username - вызов с дефолтной ставкой
• /pvp @username 5 - вызов со ставкой 5 см
• /accept @username - принять вызов

⚠️ Ограничения PvP:
• Нельзя ставить больше сантиметров, чем у вас есть
• Оппонент должен иметь достаточно сантиметров для ставки

Удачи в росте! 🚀`;
        
        await this.bot.sendMessage(chatId, helpMessage);
    }

    async handleEdit(msg, match) {
        const chatId = msg.chat.id;
        const adminId = 1634270048; // ID админа
        
        // Проверяем, является ли пользователь админом
        if (msg.from.id !== adminId) {
            await this.bot.sendMessage(chatId, '❌ У вас нет прав для выполнения этой команды.');
            return;
        }
        
        const args = match[1].split(' ');
        if (args.length !== 2) {
            await this.bot.sendMessage(chatId, '❌ Неверный формат! Используйте: /edit @username размер');
            return;
        }
        
        const targetUsername = args[0].replace('@', '');
        const newSize = parseFloat(args[1]);
        
        try {
            // Проверяем валидность размера
            if (isNaN(newSize)) {
                await this.bot.sendMessage(chatId, '❌ Неверный размер! Введите число.');
                return;
            }
            
            // Ищем пользователя по username
            const targetUser = await this.db.getUserByUsername(targetUsername);
            if (!targetUser) {
                await this.bot.sendMessage(chatId, `❌ Пользователь @${targetUsername} не найден.`);
                return;
            }
            
            const oldSize = targetUser.dick_size;
            const sizeChange = newSize - oldSize;
            
            // Обновляем размер пользователя
            await this.db.updateUserDickSize(targetUser.telegram_id, newSize, sizeChange, 'admin_edit', chatId);
            
            const message = `👑 АДМИН ИЗМЕНИЛ РАЗМЕР!
            
👤 Пользователь: ${this.getUserDisplayName(targetUser)}
📏 Было: ${this.gameLogic.formatSize(oldSize)}
📏 Стало: ${this.gameLogic.formatSize(newSize)}
📈 Изменение: ${this.gameLogic.formatGrowth(sizeChange)} ${this.gameLogic.getGrowthEmoji(sizeChange)}

Команда выполнена администратором.`;
            
            await this.bot.sendMessage(chatId, message);
            
        } catch (error) {
            console.error('Error in handleEdit:', error);
            await this.bot.sendMessage(chatId, 'Произошла ошибка при изменении размера.');
        }
    }

    async handleAcceptPvP(msg, match) {
        const chatId = msg.chat.id;
        const accepter = msg.from;
        const challengerUsername = match[1].replace('@', '');
        
        try {
            // Проверяем, существует ли пользователь
            let accepterUser = await this.db.getUser(accepter.id);
            if (!accepterUser) {
                await this.db.createUser(accepter);
                accepterUser = await this.db.getUser(accepter.id);
            }
            
            // Ищем вызывающего по username
            const challengerUser = await this.db.getUserByUsername(challengerUsername);
            if (!challengerUser) {
                await this.bot.sendMessage(chatId, `❌ Пользователь @${challengerUsername} не найден.`);
                return;
            }
            
            // Ищем ожидающее PvP сражение
            const pendingBattle = await this.db.getPendingPvPBattle(chatId, challengerUser.telegram_id, accepter.id);
            if (!pendingBattle) {
                await this.bot.sendMessage(chatId, '❌ Нет ожидающих вызовов на бой.');
                return;
            }
            
            // Проверяем, достаточно ли у принимающего вызов сантиметров для ставки
            if (accepterUser.dick_size < pendingBattle.bet_amount) {
                await this.bot.sendMessage(chatId, 
                    `❌ Недостаточно сантиметров для принятия вызова! У вас ${this.gameLogic.formatSize(accepterUser.dick_size)}, а ставка ${pendingBattle.bet_amount} см.`);
                return;
            }
            
            // Определяем победителя
            const winner = this.gameLogic.determinePvPWinner(challengerUser, accepterUser);
            const loser = winner.telegram_id === challengerUser.telegram_id ? accepterUser : challengerUser;
            
            const betAmount = pendingBattle.bet_amount;
            
            // Обновляем размеры
            const winnerNewSize = this.gameLogic.calculateNewSize(winner.dick_size, betAmount);
            const loserNewSize = this.gameLogic.calculateNewSize(loser.dick_size, -betAmount);
            
            await this.db.updateUserDickSize(winner.telegram_id, winnerNewSize, betAmount, 'pvp_win', chatId);
            await this.db.updateUserDickSize(loser.telegram_id, loserNewSize, -betAmount, 'pvp_loss', chatId);
            
            // Завершаем сражение
            await this.db.completePvPBattle(pendingBattle.id, winner.telegram_id);
            
            const message = `⚔️ БИТВА ЗАВЕРШЕНА!
            
🏆 Победитель: ${this.getUserDisplayName(winner)}
💀 Проигравший: ${this.getUserDisplayName(loser)}
💰 Ставка: ${betAmount} см

📏 Результаты:
${this.getUserDisplayName(winner)}: ${this.gameLogic.formatSize(winner.dick_size)} → ${this.gameLogic.formatSize(winnerNewSize)} ${this.gameLogic.getGrowthEmoji(betAmount)}
${this.getUserDisplayName(loser)}: ${this.gameLogic.formatSize(loser.dick_size)} → ${this.gameLogic.formatSize(loserNewSize)} ${this.gameLogic.getGrowthEmoji(-betAmount)}`;
            
            await this.bot.sendMessage(chatId, message);
            
        } catch (error) {
            console.error('Error in handleAcceptPvP:', error);
            await this.bot.sendMessage(chatId, 'Произошла ошибка при принятии PvP вызова.');
        }
    }

    getUserDisplayName(user) {
        if (user.first_name && user.last_name) {
            return `${user.first_name} ${user.last_name}`;
        } else if (user.first_name) {
            return user.first_name;
        } else if (user.username) {
            return `@${user.username}`;
        } else {
            return `User${user.id}`;
        }
    }

    stop() {
        this.bot.stopPolling();
        this.db.close();
    }
}

module.exports = DickGrowthBot; 