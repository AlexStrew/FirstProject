const sqlite3 = require('sqlite3').verbose();
const path = require('path');

class Database {
    constructor() {
        this.db = new sqlite3.Database(path.join(__dirname, 'dick_bot.db'));
        this.init();
    }

    init() {
        this.db.serialize(() => {
            // Таблица пользователей
            this.db.run(`
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY,
                    telegram_id INTEGER UNIQUE,
                    username TEXT,
                    first_name TEXT,
                    last_name TEXT,
                    dick_size REAL DEFAULT 10.0,
                    last_grow_date TEXT,
                    loan_amount REAL DEFAULT 0.0,
                    total_grows INTEGER DEFAULT 0,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            `);

            // Таблица чатов
            this.db.run(`
                CREATE TABLE IF NOT EXISTS chats (
                    id INTEGER PRIMARY KEY,
                    telegram_id INTEGER UNIQUE,
                    title TEXT,
                    last_dod_date TEXT,
                    dod_winner_id INTEGER,
                    dod_announcement_shows INTEGER DEFAULT 0,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            `);

            // Таблица PvP сражений
            this.db.run(`
                CREATE TABLE IF NOT EXISTS pvp_battles (
                    id INTEGER PRIMARY KEY,
                    chat_id INTEGER,
                    challenger_id INTEGER,
                    opponent_id INTEGER,
                    bet_amount INTEGER,
                    winner_id INTEGER,
                    status TEXT DEFAULT 'pending',
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            `);

            // Таблица истории роста
            this.db.run(`
                CREATE TABLE IF NOT EXISTS growth_history (
                    id INTEGER PRIMARY KEY,
                    user_id INTEGER,
                    chat_id INTEGER,
                    growth_amount REAL,
                    new_size REAL,
                    reason TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            `);
        });
    }

    // Методы для работы с пользователями
    async getUser(telegramId) {
        return new Promise((resolve, reject) => {
            this.db.get(
                'SELECT * FROM users WHERE telegram_id = ?',
                [telegramId],
                (err, row) => {
                    if (err) reject(err);
                    else resolve(row);
                }
            );
        });
    }

    async getUserByUsername(username) {
        return new Promise((resolve, reject) => {
            this.db.get(
                'SELECT * FROM users WHERE username = ?',
                [username],
                (err, row) => {
                    if (err) reject(err);
                    else resolve(row);
                }
            );
        });
    }

    async createUser(userData) {
        return new Promise((resolve, reject) => {
            this.db.run(
                `INSERT INTO users (telegram_id, username, first_name, last_name) 
                 VALUES (?, ?, ?, ?)`,
                [userData.id, userData.username, userData.first_name, userData.last_name],
                function(err) {
                    if (err) reject(err);
                    else resolve(this.lastID);
                }
            );
        });
    }

    async updateUserDickSize(telegramId, newSize, growthAmount, reason, chatId) {
        return new Promise((resolve, reject) => {
            this.db.serialize(() => {
                // Обновляем размер
                this.db.run(
                    `UPDATE users SET dick_size = ?, last_grow_date = CURRENT_TIMESTAMP, 
                     total_grows = total_grows + 1 WHERE telegram_id = ?`,
                    [newSize, telegramId],
                    function(err) {
                        if (err) reject(err);
                    }
                );

                // Записываем в историю
                this.db.run(
                    `INSERT INTO growth_history (user_id, chat_id, growth_amount, new_size, reason) 
                     VALUES ((SELECT id FROM users WHERE telegram_id = ?), ?, ?, ?, ?)`,
                    [telegramId, chatId, growthAmount, newSize, reason],
                    function(err) {
                        if (err) reject(err);
                        else resolve();
                    }
                );
            });
        });
    }

    // Методы для работы с чатами
    async getChat(telegramId) {
        return new Promise((resolve, reject) => {
            this.db.get(
                'SELECT * FROM chats WHERE telegram_id = ?',
                [telegramId],
                (err, row) => {
                    if (err) reject(err);
                    else resolve(row);
                }
            );
        });
    }

    async createChat(chatData) {
        return new Promise((resolve, reject) => {
            this.db.run(
                `INSERT INTO chats (telegram_id, title) VALUES (?, ?)`,
                [chatData.id, chatData.title],
                function(err) {
                    if (err) reject(err);
                    else resolve(this.lastID);
                }
            );
        });
    }

    async updateChatDOD(telegramId, winnerId) {
        return new Promise((resolve, reject) => {
            this.db.run(
                `UPDATE chats SET last_dod_date = CURRENT_TIMESTAMP, dod_winner_id = ? 
                 WHERE telegram_id = ?`,
                [winnerId, telegramId],
                function(err) {
                    if (err) reject(err);
                    else resolve();
                }
            );
        });
    }

    // Методы для рейтинга
    async getTopUsers(limit = 10) {
        return new Promise((resolve, reject) => {
            this.db.all(
                `SELECT telegram_id, username, first_name, last_name, dick_size, total_grows 
                 FROM users ORDER BY dick_size DESC LIMIT ?`,
                [limit],
                (err, rows) => {
                    if (err) reject(err);
                    else resolve(rows);
                }
            );
        });
    }

    async getTopUsersByChat(chatId, limit = 10) {
        return new Promise((resolve, reject) => {
            this.db.all(
                `SELECT u.telegram_id, u.username, u.first_name, u.last_name, u.dick_size, u.total_grows
                 FROM users u
                 WHERE u.telegram_id IN (
                     SELECT DISTINCT gh.user_id 
                     FROM growth_history gh 
                     WHERE gh.chat_id = ?
                 )
                 ORDER BY u.dick_size DESC LIMIT ?`,
                [chatId, limit],
                (err, rows) => {
                    if (err) reject(err);
                    else resolve(rows);
                }
            );
        });
    }

    // Методы для PvP
    async createPvPBattle(chatId, challengerId, opponentId, betAmount) {
        return new Promise((resolve, reject) => {
            this.db.run(
                `INSERT INTO pvp_battles (chat_id, challenger_id, opponent_id, bet_amount) 
                 VALUES (?, ?, ?, ?)`,
                [chatId, challengerId, opponentId, betAmount],
                function(err) {
                    if (err) reject(err);
                    else resolve(this.lastID);
                }
            );
        });
    }

    async getPendingPvPBattle(chatId, challengerId, opponentId) {
        return new Promise((resolve, reject) => {
            this.db.get(
                `SELECT * FROM pvp_battles 
                 WHERE chat_id = ? AND challenger_id = ? AND opponent_id = ? AND status = 'pending'`,
                [chatId, challengerId, opponentId],
                (err, row) => {
                    if (err) reject(err);
                    else resolve(row);
                }
            );
        });
    }

    async completePvPBattle(battleId, winnerId) {
        return new Promise((resolve, reject) => {
            this.db.run(
                `UPDATE pvp_battles SET winner_id = ?, status = 'completed' WHERE id = ?`,
                [winnerId, battleId],
                function(err) {
                    if (err) reject(err);
                    else resolve();
                }
            );
        });
    }

    // Методы для Писюна Дня
    async getActiveGrowers(chatId, days = 7) {
        return new Promise((resolve, reject) => {
            this.db.all(
                `SELECT DISTINCT u.telegram_id, u.username, u.first_name, u.last_name, u.dick_size
                 FROM users u
                 JOIN growth_history gh ON u.id = gh.user_id
                 WHERE gh.chat_id = ? AND gh.created_at >= datetime('now', '-${days} days')
                 ORDER BY u.dick_size ASC`,
                [chatId],
                (err, rows) => {
                    if (err) reject(err);
                    else resolve(rows);
                }
            );
        });
    }

    // Методы для кредита
    async updateLoan(telegramId, loanAmount) {
        return new Promise((resolve, reject) => {
            this.db.run(
                `UPDATE users SET loan_amount = ? WHERE telegram_id = ?`,
                [loanAmount, telegramId],
                function(err) {
                    if (err) reject(err);
                    else resolve();
                }
            );
        });
    }

    close() {
        this.db.close();
    }
}

module.exports = Database; 