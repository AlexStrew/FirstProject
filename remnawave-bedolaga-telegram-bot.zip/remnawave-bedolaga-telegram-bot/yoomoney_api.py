import asyncio
import logging
import aiohttp
import hashlib
import hmac
from typing import Optional, Dict, Any
from datetime import datetime
from config import Config

logger = logging.getLogger(__name__)

class YouMoneyAPI:
    """Класс для работы с YouMoney API"""
    
    def __init__(self, config: Config):
        self.config = config
        self.base_url = "https://yoomoney.ru/api"
        self.token = config.YOOMONEY_TOKEN
        self.account = config.YOOMONEY_ACCOUNT
        self.webhook_secret = config.YOOMONEY_WEBHOOK_SECRET
        
    async def create_payment_form(self, amount: float, payment_id: str, description: str) -> Optional[Dict[str, Any]]:
        """Создает форму для оплаты через YouMoney"""
        if not self.config.YOOMONEY_ENABLED:
            logger.warning("YouMoney integration is disabled")
            return None
            
        try:
            # Создаем форму для оплаты
            form_data = {
                "receiver": self.account,
                "quickpay-form": "shop",
                "targets": description,
                "payment-type": "AC",
                "sum": str(amount),
                "label": f"payment_{payment_id}",
                "successURL": f"https://t.me/{self.config.BOT_USERNAME}?start=payment_success_{payment_id}",
                "failURL": f"https://t.me/{self.config.BOT_USERNAME}?start=payment_fail_{payment_id}"
            }
            
            # Формируем URL для оплаты
            payment_url = "https://yoomoney.ru/quickpay/button-widget"
            
            return {
                "payment_url": payment_url,
                "form_data": form_data,
                "payment_id": payment_id,
                "amount": amount,
                "description": description
            }
            
        except Exception as e:
            logger.error(f"Error creating YouMoney payment form: {e}")
            return None
    
    async def check_payment_status(self, payment_id: str) -> Optional[Dict[str, Any]]:
        """Проверяет статус платежа через YouMoney API"""
        if not self.config.YOOMONEY_ENABLED or not self.token:
            logger.warning("YouMoney integration is disabled or token not provided")
            return None
            
        try:
            async with aiohttp.ClientSession() as session:
                # Получаем информацию о платежах с меткой
                params = {
                    "token": self.token,
                    "label": f"payment_{payment_id}"
                }
                
                async with session.get(f"{self.base_url}/v3/operations", params=params) as response:
                    if response.status == 200:
                        data = await response.json()
                        
                        if data.get("operations"):
                            operation = data["operations"][0]
                            
                            return {
                                "payment_id": payment_id,
                                "status": "completed" if operation.get("status") == "success" else "pending",
                                "amount": float(operation.get("amount", 0)),
                                "operation_id": operation.get("id"),
                                "timestamp": operation.get("datetime"),
                                "description": operation.get("title", "")
                            }
                        
                        return {
                            "payment_id": payment_id,
                            "status": "pending",
                            "amount": 0.0,
                            "operation_id": None,
                            "timestamp": None,
                            "description": ""
                        }
                    else:
                        logger.error(f"YouMoney API error: {response.status}")
                        return None
                        
        except Exception as e:
            logger.error(f"Error checking YouMoney payment status: {e}")
            return None
    
    def verify_webhook_signature(self, body: str, signature: str) -> bool:
        """Проверяет подпись webhook от YouMoney"""
        if not self.webhook_secret:
            logger.warning("Webhook secret not configured")
            return False
            
        try:
            expected_signature = hmac.new(
                self.webhook_secret.encode('utf-8'),
                body.encode('utf-8'),
                hashlib.sha256
            ).hexdigest()
            
            return hmac.compare_digest(signature, expected_signature)
            
        except Exception as e:
            logger.error(f"Error verifying webhook signature: {e}")
            return False
    
    async def get_account_info(self) -> Optional[Dict[str, Any]]:
        """Получает информацию об аккаунте YouMoney"""
        if not self.config.YOOMONEY_ENABLED or not self.token:
            return None
            
        try:
            async with aiohttp.ClientSession() as session:
                params = {"token": self.token}
                
                async with session.get(f"{self.base_url}/v3/account-info", params=params) as response:
                    if response.status == 200:
                        return await response.json()
                    else:
                        logger.error(f"Error getting YouMoney account info: {response.status}")
                        return None
                        
        except Exception as e:
            logger.error(f"Error getting YouMoney account info: {e}")
            return None
